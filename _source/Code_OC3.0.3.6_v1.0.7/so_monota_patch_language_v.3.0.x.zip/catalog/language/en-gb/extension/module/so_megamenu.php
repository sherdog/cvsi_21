<?php
// Text
$_['text_more_category']           = "More Categories";
$_['text_close_category']          = "Close Categories";
