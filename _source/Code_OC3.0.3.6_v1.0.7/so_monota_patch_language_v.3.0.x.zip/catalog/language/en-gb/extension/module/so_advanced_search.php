<?php
// Heading
$_['heading_title'] = 'Select Your Vehical';

// Text
$_['text_select_make']      	= 'Select Make';
$_['text_select_model']      	= 'Select Model';
$_['text_select_engine']      	= 'Select Engine';
$_['text_select_year']      	= 'Select Year';

// Button
$_['button_search'] = 'Find My Part';