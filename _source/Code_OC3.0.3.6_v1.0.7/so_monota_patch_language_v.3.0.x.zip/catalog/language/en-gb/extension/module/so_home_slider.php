<?php
// Heading
$_['heading_title'] = 'So home slider';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_noitem']      = $_['heading_title'].': Has no item to show!';