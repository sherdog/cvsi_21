<?php
// Heading
$_['heading_title']    = 'Photos';

$_['text_albums']    	 = 'Albums';