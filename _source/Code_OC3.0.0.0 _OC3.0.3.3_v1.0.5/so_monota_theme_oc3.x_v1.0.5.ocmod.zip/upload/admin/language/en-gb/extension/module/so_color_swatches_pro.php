<?php

$_['heading_title']				= 'So Color Swatches Pro';
$_['heading_title_so']			= 'So Color Swatch Pro <b style="font-size:10px; background:#aaa; color:#fff; padding: 3px;font-weight:normal">version 1.0.1</b>';

$_['entry_status']				= 'Status';
$_['entry_option']				= 'Select option to applied color swatch';
$_['entry_type']				= 'Color Swatch Type';
$_['entry_general_settings']	= 'General Settings';
$_['entry_product_list']		= 'Product List';
$_['entry_product_page']		= 'Product Page';
$_['entry_enable']				= 'Enable';
$_['entry_icon_swatch_width']	= 'Icon swatch width';
$_['entry_icon_swatch_height']	= 'Icon swatch height';

$_['text_edit']					= 'Edit Color Swatches Pro Module';
$_['text_status']				= 'Status';
$_['text_status_help']			= 'Enabled/Disabled module';
$_['text_name']					= 'Name';
$_['text_click']				= 'Click';
$_['text_hover']				= 'Hover';
$_['text_success']				= 'Success: You have modified So Color Swatches Pro module!';
$_['error_permission']			= 'Warning: You do not have permission to modify module!';
$_['error_warning']				= 'Warning: You must check module careful';

$_['button_savestay']			= 'Save & Stay';