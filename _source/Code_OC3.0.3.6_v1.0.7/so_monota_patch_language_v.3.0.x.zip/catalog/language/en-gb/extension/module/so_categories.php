<?php
// Heading
$_['heading_title'] = 'So listing tabs';

// Text
$_['text_nocate']   = 'No categories to show !';
$_['text_noitem']   = 'No item to show !';
$_['text_viewmore']   = 'View More';
