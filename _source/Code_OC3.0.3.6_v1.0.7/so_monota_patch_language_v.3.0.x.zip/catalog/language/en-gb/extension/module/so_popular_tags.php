<?php
// Heading
$_['heading_title'] = 'So Popular Tabs';

// Messages
$_['text_notags']  		= 'No tags available';