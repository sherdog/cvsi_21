<?php
// Heading
//$_['direction']  		= 'ltr';
$_['text_latest']  		= 'Latest'; 
$_['text_comment']     	= ' Comment';
$_['text_comments']    	= ' Comments';
$_['text_view']        	= ' View';
$_['text_views']       	= ' Views';
// Text
$_['text_none_author'] 	= 'None Author';
$_['text_tax']      	= 'Ex Tax:';
$_['text_noitem']      	= 'Has no item to show!';
$_['text_no_database'] 	= 'Simple Blog have installed yet. Please Install it following  <a href="http://images.smartaddons.com/Open-cart-theme/support/video-guide/simple_blog_config.webm" target="_blank">the guide here </a>!';

$_['text_by']        	= ' By';
$_['text_on']        	= ' on';