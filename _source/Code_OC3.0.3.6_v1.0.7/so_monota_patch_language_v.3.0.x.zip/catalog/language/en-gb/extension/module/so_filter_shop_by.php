<?php
// Heading
$_['heading_title'] = 'So Filter Shop By';

// Text
$_['text_tax']      		= 'Ex Tax:';
$_['text_noproduct']      	= 'Has no item to show!';
$_['text_empty']      		= 'There are no products to list in this filter.';
$_['text_sale']      		= 'Sale';
$_['text_new']      		= 'New';

$_['text_search']      		= 'Search';
$_['text_price']      		= 'Price';
$_['text_reset_all']      	= 'Reset All';
$_['text_manufacturer']     = 'Manufacturer';
$_['text_subcategory']     	= 'SubCategory';
$_['button_cart']     		= 'Add to cart';