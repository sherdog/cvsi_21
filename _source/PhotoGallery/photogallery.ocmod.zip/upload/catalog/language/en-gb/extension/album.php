<?php
// Heading
$_['heading_title']    = 'Albums';

$_['text_albums']    	 = 'Albums';