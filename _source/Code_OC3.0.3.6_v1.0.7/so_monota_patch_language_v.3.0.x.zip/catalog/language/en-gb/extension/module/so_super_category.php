<?php
// Heading
$_['heading_title'] = 'So Super Category';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_date']      = 'Date: ';
// So super category
$_['all_ready_label'] 	= 'All ready';
$_['load_more_label'] 	= 'Load more';
$_['value_price'] 		= 'Price';
$_['value_name'] 		= 'Name';
$_['value_model'] 		= 'Model';
$_['value_quantity'] 	= 'Quantity';
$_['value_rating'] 		= 'Featured';
$_['value_sort_add'] 	= 'Sort Add';
$_['value_date_add'] 	= 'New Arrivals';
$_['value_sale'] 		= 'Best sellers';
$_['text_noitem']      = 'Has no item to show!';
$_['text_sale']      	= 'Sale';
$_['text_new']      	= 'New';
$_['button_cart']      	= 'Add to cart';
$_['text_view_all']      	= 'View all';