<?php

$_['error_name'] = "Name is Required.";
$_['error_email'] = "Email is Required.";
$_['error_number'] = "Phone is Required.";
$_['error_message'] = "Question is Required.";

$_['text_success'] = "Thanks for your inquiry.";
$_['text_email_not_sent'] = "Email can't sent.";

$_['text_subject'] = 'Ask Question for %s';
$_['text_form_title'] = 'Ask Product Question';
$_['text_name'] = 'Your Name';
$_['text_email'] = 'Your E-mail';
$_['text_phone'] = 'Your Phone';
$_['text_question'] = 'Question';
$_['text_submit'] = 'Submit Question';
$_['text_button_name'] = 'Ask Question';
$_['text_askquestion_product_desc'] = 'Click to ask about this product';