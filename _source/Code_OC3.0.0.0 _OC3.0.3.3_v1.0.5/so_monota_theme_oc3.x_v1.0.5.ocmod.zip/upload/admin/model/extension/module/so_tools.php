<?php

class ModelExtensionModuleSoTools extends Model {
	
}