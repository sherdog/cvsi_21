<?php
// Text
$_['input_check']           = "Don't show this popup again";
$_['label_email']           = "Enter Email";
$_['newsletter_placeholder']= "Your email address...";
$_['newsletter_button']     = "Subscribe";
$_['text_email_required']     = "Email is required";

$_['error_email_exist']     = "Email has already exist";
$_['error_subcription']     = "Subcription Fail";
$_['success_subcription']   = "Subcription was successfull";
