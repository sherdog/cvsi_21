<?php
// Heading
$_['heading_title'] = 'Gallery';

// Text
$_['text_tax']      = 'Ex Tax:';