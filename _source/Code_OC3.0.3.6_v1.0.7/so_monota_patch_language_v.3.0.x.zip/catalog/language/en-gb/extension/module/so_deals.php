<?php
// Heading
$_['heading_title'] = 'So deals';

// Text
$_['text_tax']      		= 'Ex Tax:';
$_['text_noitem']      		= 'Has no item to show!';
$_['text_sale']      		= 'Sale';
$_['text_new']      		= 'New';