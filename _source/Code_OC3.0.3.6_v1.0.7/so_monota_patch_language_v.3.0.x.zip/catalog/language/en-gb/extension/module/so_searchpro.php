<?php
// Text
$_['text_search']    	= 'Keyword here...';
$_['text_category_all'] = 'All Categories';
$_['text_tax']      	= 'Tax';
$_['text_price']      	= 'Price';
$_['button_cart']       = 'Add to Cart';
$_['button_wishlist']       = 'Add to Wish List';
$_['button_compare']       = 'Add to Compare';
$_['text_btn_search']    	= 'Search';